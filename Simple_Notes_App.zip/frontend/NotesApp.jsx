import React, { useEffect, useState } from 'react';
import { Card, CardContent, Button } from '@/components/ui/card';
import axios from 'axios';

export default function NotesApp() {
    const [notes, setNotes] = useState([]);
    const [title, setTitle] = useState('');
    const [content, setContent] = useState('');

    useEffect(() => {
        fetchNotes();
    }, []);

    const fetchNotes = async () => {
        const response = await axios.get('/api/notes');
        setNotes(response.data);
    };

    const addNote = async () => {
        await axios.post('/api/notes', { title, content });
        setTitle('');
        setContent('');
        fetchNotes();
    };

    const deleteNote = async (id) => {
        if (confirm('Are you sure you want to delete this note?')) {
            await axios.delete(`/api/notes/${id}`);
            fetchNotes();
        }
    };

    return (
        <div className="p-4 max-w-lg mx-auto">
            <h1 className="text-2xl font-bold mb-4">Simple Notes App</h1>
            <input className="w-full mb-2 p-2 border rounded" placeholder="Title" value={title} onChange={(e) => setTitle(e.target.value)} />
            <textarea className="w-full mb-2 p-2 border rounded" placeholder="Content" value={content} onChange={(e) => setContent(e.target.value)} />
            <Button onClick={addNote} className="mb-4">Add Note</Button>
            {notes.map((note) => (
                <Card key={note.id} className="mb-2">
                    <CardContent>
                        <h2 className="text-xl font-semibold">{note.title}</h2>
                        <p>{note.content.slice(0, 50)}...</p>
                        <Button variant="destructive" onClick={() => deleteNote(note.id)}>Delete</Button>
                    </CardContent>
                </Card>
            ))}
        </div>
    );
}
